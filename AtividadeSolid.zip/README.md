# Projeto: Aplicação dos Princípios SOLID

Este projeto contém um exemplo de código orientado a objetos para um sistema bancário, com duas versões:

- `original/` → Código inicial, sem aplicação explícita de SOLID.  
- `solid/` → Código refatorado, aplicando princípios SOLID.  

---

## Cliente

### a) Classe Original
```python
class Cliente:
    def __init__(self, nome: str, cpf: str):
        self.nome = nome
        self.cpf = cpf
        self.contas: List["Conta"] = []
```

### b) Princípio SOLID Aplicado
Princípio: **SRP (Responsabilidade Única)**  
Explicação: O `Cliente` já estava bem definido, sem responsabilidades extras. Foi mantido, mas ajustado para aceitar abstrações de conta (`IConta`), garantindo **DIP**.

### c) Classe Refatorada
```python
class Cliente:
    def __init__(self, nome: str, cpf: str):
        self.nome = nome
        self.cpf = cpf
        self.contas: List[IConta] = []
```

---

## Conta

### a) Classe Original
```python
class Conta:
    def depositar(self, valor: float): ...
    def sacar(self, valor: float): ...
    def transferir(self, destino: "Conta", valor: float): ...
```

### b) Princípio SOLID Aplicado
Princípio: **OCP (Aberto/Fechado)** e **DIP (Inversão de Dependência)**  
Explicação: Antes, `Conta` era fixa. Agora criamos uma **interface `IConta`** e uma implementação concreta `ContaCorrente`.  
Isso permite adicionar novos tipos de contas sem modificar o código existente.

### c) Classe Refatorada
```python
class IConta(ABC):
    @abstractmethod
    def depositar(self, valor: float): pass
    @abstractmethod
    def sacar(self, valor: float): pass
    @abstractmethod
    def transferir(self, destino: "IConta", valor: float): pass

class ContaCorrente(IConta): ...
```

---

## Banco

### a) Classe Original
```python
class Banco:
    def listar_clientes_e_contas(self):
        for cliente in self.clientes:
            print(cliente)
            for conta in cliente.contas:
                print(" ", conta)
```

### b) Princípio SOLID Aplicado
Princípio: **SRP (Responsabilidade Única)**  
Explicação: O `Banco` cuidava da lógica de negócio e da exibição (`print`).  
Agora a responsabilidade de exibir foi movida para a classe `RelatorioBanco`.

### c) Classe Refatorada
```python
class RelatorioBanco:
    @staticmethod
    def listar_clientes_e_contas(banco: Banco):
        for cliente in banco.clientes:
            print(cliente)
            for conta in cliente.contas:
                print(" ", conta)
```

---

# Conclusão
- **SRP:** Separação de responsabilidades (`Banco` vs `RelatorioBanco`).  
- **OCP:** Inclusão da interface `IConta`, permitindo expansão sem modificar código existente.  
- **DIP:** O `Banco` e o `Cliente` agora trabalham com abstrações (`IConta`) ao invés de implementações concretas.  
