from typing import List

class Cliente:
    def __init__(self, nome: str, cpf: str):
        self.nome = nome
        self.cpf = cpf
        self.contas: List["Conta"] = []

    def adicionar_conta(self, conta: "Conta"):
        self.contas.append(conta)

    def __str__(self):
        return f"Cliente: {self.nome} (CPF: {self.cpf})"


class Conta:
    def __init__(self, numero: int, cliente: Cliente, saldo: float = 0.0):
        self.numero = numero
        self.saldo = saldo
        self.cliente = cliente

    def depositar(self, valor: float):
        if valor <= 0:
            raise ValueError("Valor do depósito deve ser positivo")
        self.saldo += valor

    def sacar(self, valor: float):
        if valor <= 0:
            raise ValueError("Valor do saque deve ser positivo")
        if valor > self.saldo:
            raise ValueError("Saldo insuficiente")
        self.saldo -= valor

    def transferir(self, destino: "Conta", valor: float):
        self.sacar(valor)
        destino.depositar(valor)

    def __str__(self):
        return f"Conta {self.numero} | Saldo: R${self.saldo:.2f}"


class Banco:
    def __init__(self, nome: str):
        self.nome = nome
        self.clientes: List[Cliente] = []
        self.contas: List[Conta] = []

    def adicionar_cliente(self, cliente: Cliente):
        self.clientes.append(cliente)

    def adicionar_conta(self, conta: Conta):
        self.contas.append(conta)
        conta.cliente.adicionar_conta(conta)

    def listar_clientes_e_contas(self):
        for cliente in self.clientes:
            print(cliente)
            for conta in cliente.contas:
                print(" ", conta)

    def buscar_conta(self, numero: int) -> Conta:
        for conta in self.contas:
            if conta.numero == numero:
                return conta
        raise ValueError("Conta não encontrada")


def criar_dados_mock():
    banco = Banco("Banco GPT")
    c1 = Cliente("Ana Souza", "111.111.111-11")
    c2 = Cliente("João Silva", "222.222.222-22")

    conta1 = Conta(1001, c1, 500)
    conta2 = Conta(1002, c1, 1500)
    conta3 = Conta(2001, c2, 1000)

    banco.adicionar_cliente(c1)
    banco.adicionar_cliente(c2)
    banco.adicionar_conta(conta1)
    banco.adicionar_conta(conta2)
    banco.adicionar_conta(conta3)

    return banco


if __name__ == "__main__":
    banco = criar_dados_mock()

    print("=== LISTA DE CLIENTES E CONTAS ===")
    banco.listar_clientes_e_contas()

    print("\n=== OPERAÇÕES ===")
    conta_origem = banco.buscar_conta(1001)
    conta_destino = banco.buscar_conta(2001)

    print("Antes da transferência:")
    print(conta_origem)
    print(conta_destino)

    conta_origem.transferir(conta_destino, 200)

    print("\nDepois da transferência:")
    print(conta_origem)
    print(conta_destino)

    print("\nDepósito de 300 na conta 1002")
    banco.buscar_conta(1002).depositar(300)

    print("\nSaque de 100 na conta 2001")
    banco.buscar_conta(2001).sacar(100)

    print("\n=== LISTA FINAL ===")
    banco.listar_clientes_e_contas()
